// generated from rosidl_generator_c/resource/idl.h.em
// with input from ros2_socketcan_msgs:msg/FdFrame.idl
// generated code does not contain a copyright notice

#ifndef ROS2_SOCKETCAN_MSGS__MSG__FD_FRAME_H_
#define ROS2_SOCKETCAN_MSGS__MSG__FD_FRAME_H_

#include "ros2_socketcan_msgs/msg/detail/fd_frame__struct.h"
#include "ros2_socketcan_msgs/msg/detail/fd_frame__functions.h"
#include "ros2_socketcan_msgs/msg/detail/fd_frame__type_support.h"

#endif  // ROS2_SOCKETCAN_MSGS__MSG__FD_FRAME_H_
