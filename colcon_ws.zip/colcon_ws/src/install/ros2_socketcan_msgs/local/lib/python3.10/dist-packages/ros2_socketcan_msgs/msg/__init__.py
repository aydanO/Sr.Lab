from ros2_socketcan_msgs.msg._fd_frame import FdFrame  # noqa: F401
