// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SCOUT_MINI_MSGS__MSG__LIGHT_COMMAND_HPP_
#define SCOUT_MINI_MSGS__MSG__LIGHT_COMMAND_HPP_

#include "scout_mini_msgs/msg/detail/light_command__struct.hpp"
#include "scout_mini_msgs/msg/detail/light_command__builder.hpp"
#include "scout_mini_msgs/msg/detail/light_command__traits.hpp"

#endif  // SCOUT_MINI_MSGS__MSG__LIGHT_COMMAND_HPP_
