// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SCOUT_MINI_MSGS__MSG__ROBOT_STATE_HPP_
#define SCOUT_MINI_MSGS__MSG__ROBOT_STATE_HPP_

#include "scout_mini_msgs/msg/detail/robot_state__struct.hpp"
#include "scout_mini_msgs/msg/detail/robot_state__builder.hpp"
#include "scout_mini_msgs/msg/detail/robot_state__traits.hpp"

#endif  // SCOUT_MINI_MSGS__MSG__ROBOT_STATE_HPP_
