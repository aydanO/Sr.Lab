// generated from rosidl_generator_c/resource/idl.h.em
// with input from scout_mini_msgs:msg/LightCommand.idl
// generated code does not contain a copyright notice

#ifndef SCOUT_MINI_MSGS__MSG__LIGHT_COMMAND_H_
#define SCOUT_MINI_MSGS__MSG__LIGHT_COMMAND_H_

#include "scout_mini_msgs/msg/detail/light_command__struct.h"
#include "scout_mini_msgs/msg/detail/light_command__functions.h"
#include "scout_mini_msgs/msg/detail/light_command__type_support.h"

#endif  // SCOUT_MINI_MSGS__MSG__LIGHT_COMMAND_H_
