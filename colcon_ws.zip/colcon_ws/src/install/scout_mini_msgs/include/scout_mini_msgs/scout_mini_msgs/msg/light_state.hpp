// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SCOUT_MINI_MSGS__MSG__LIGHT_STATE_HPP_
#define SCOUT_MINI_MSGS__MSG__LIGHT_STATE_HPP_

#include "scout_mini_msgs/msg/detail/light_state__struct.hpp"
#include "scout_mini_msgs/msg/detail/light_state__builder.hpp"
#include "scout_mini_msgs/msg/detail/light_state__traits.hpp"

#endif  // SCOUT_MINI_MSGS__MSG__LIGHT_STATE_HPP_
