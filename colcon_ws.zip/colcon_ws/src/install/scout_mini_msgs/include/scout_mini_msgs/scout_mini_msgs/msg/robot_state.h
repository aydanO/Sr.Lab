// generated from rosidl_generator_c/resource/idl.h.em
// with input from scout_mini_msgs:msg/RobotState.idl
// generated code does not contain a copyright notice

#ifndef SCOUT_MINI_MSGS__MSG__ROBOT_STATE_H_
#define SCOUT_MINI_MSGS__MSG__ROBOT_STATE_H_

#include "scout_mini_msgs/msg/detail/robot_state__struct.h"
#include "scout_mini_msgs/msg/detail/robot_state__functions.h"
#include "scout_mini_msgs/msg/detail/robot_state__type_support.h"

#endif  // SCOUT_MINI_MSGS__MSG__ROBOT_STATE_H_
