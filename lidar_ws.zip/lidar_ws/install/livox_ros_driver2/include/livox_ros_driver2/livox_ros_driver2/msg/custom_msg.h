// generated from rosidl_generator_c/resource/idl.h.em
// with input from livox_ros_driver2:msg/CustomMsg.idl
// generated code does not contain a copyright notice

#ifndef LIVOX_ROS_DRIVER2__MSG__CUSTOM_MSG_H_
#define LIVOX_ROS_DRIVER2__MSG__CUSTOM_MSG_H_

#include "livox_ros_driver2/msg/detail/custom_msg__struct.h"
#include "livox_ros_driver2/msg/detail/custom_msg__functions.h"
#include "livox_ros_driver2/msg/detail/custom_msg__type_support.h"

#endif  // LIVOX_ROS_DRIVER2__MSG__CUSTOM_MSG_H_
